//ANA CAROLINA MARTINS SANTOS TEIXEIRA, DS2A30
namespace facade
{
    // Classe responsável por simular o processamento do pagamento
    public class Pagamento
    {
        public void ProcessarPagamento(double valor)
        {
            // Aqui simulamos que o valor foi processado com sucesso
            Console.WriteLine($"✔ Pagamento de R${valor} processado com sucesso.");
        }
    }
}
