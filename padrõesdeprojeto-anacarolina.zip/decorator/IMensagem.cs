//ANA CAROLINA MARTINS SANTOS TEIXEIRA, DS2A30
namespace decorator
{
    // Interface base que define o contrato para qualquer mensagem
    public interface IMensagem
    {
        string Formatar();
    }
}
